function [MinimumNumberofTrays,HKB,LKT] = Fenskeequation(relativeVolatilities,LK)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
Temp2 =input("Please give recovery of Heavy key component in bottom:  ", 's');

if isnan(str2double(Temp2))
    error('Invalid input. Please enter a numeric value.');
end
Temp2=str2double(Temp2)
if Temp2<0
    error("Have some positivity");

elseif Temp2>1
   
    error("Too much positivity");
else
    
    display("Your Heavy key component Recovery is noted.");

end
HKB=Temp2;
HKT=1-Temp2;
Temp1 =input("Please give recovery of Light key component in Top:  ", 's');
if isnan(str2double(Temp1))
    error('Invalid input. Please enter a numeric value.');
end
Temp1=str2double(Temp1);
if Temp1<0
    error("Have some positivity");

elseif Temp1>1
    error("Too much positivity");
else
    
    display("Your Light key component Recovery is noted.");

end
LKT=Temp1;
LKB=1-Temp1;
Num1=LKT/LKB
Num2=HKB/HKT

Num3=relativeVolatilities(LK)
Num4=log(Num1*Num2)
MinimumNumberofTrays=Num4/log(Num3)

end