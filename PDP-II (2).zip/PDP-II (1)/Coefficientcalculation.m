function Coefficientss  = Coefficientcalculation(relativeVolatilities,theta,NumberofCompounds)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
for i=1:(NumberofCompounds-1)
    for j=1:NumberofCompounds
        Coefficientss(i,j)=relativeVolatilities(j)/(relativeVolatilities(j)-theta(i));
    end
end

A=Coefficientss
B=ones(4,1);
C=[A,B]
end