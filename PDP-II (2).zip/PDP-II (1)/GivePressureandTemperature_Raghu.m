function [Pressure,Temperature] = GivePressureandTemperature_Raghu()
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
 Temp1=input("Enter the pressure " , 's');
 if isnan(str2double(Temp1))
    error('Invalid input. Please enter a numeric value.');
 end
 Pressure=str2double(Temp1);
 if Pressure==0
     error('Pressure cannot be zero');
 end
 
 Temp2=input("Enter the Temperature ",'s');
 if isnan(str2double(Temp2))
    error('Invalid input. Please enter a numeric value.');
 end
 Temperature=str2double(Temp2);
end