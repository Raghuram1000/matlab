close all

% Given Compounds
Compounds = ["Ethane", "Propane", "n-Butane","n-Pentane","n-Hexane"];
Compoundsnumvalues=[1,2,3,4,5];
%P=2;
%T=400;
NumberofCompounds=5;
A=[9.0435,9.1058,9.0580,9.2131,9.2164];
B=[1511.4,1872.5,2154.9,2477.9,2697.6];
C=[-17.16,-25.16,-34.42,-39.94,-49.78];
Flowrate=[5,25,30,20,20];
display("Please enter the operating pressure and temperature. ONLY NUMERIC VALUES ARE ACCEPTED");
[P,T]=GivePressureandTemperature_Raghu();
Kvalues=CalculateKvalues_Raghu(A,B,C,P,T)
display('Now we have K values time to take relative volatality.');
[relativeVolatilities,LK,HK] = getRelativeVolatility_Raghu(Kvalues)
%relativeVolatilitiesgivenn=[16.5,10.5,9.04,5.74,5.10,2.92,1.70,1.00];
%LK=3;
%HK=4;
%for i=1:8
   % relativeVolatilities(i)=relativeVolatilitiesgivenn(i)/relativeVolatilitiesgiven(HK);
%end
relativeVolatilities
[MinimumNumberofTrays,HKB,LKT] = Fenskeequation(relativeVolatilities,LK);
display("Now our net target is to solve Underwood equation");
disp(size(Flowrate))

TotalFLowRate=sum(Flowrate)
Molefractions=Flowrate/TotalFLowRate
%Next step is calculating theta values
Numberofthetavalues=4;
%theta=zeros(7,1);
for i=1:Numberofthetavalues
    LowerLimit=relativeVolatilities(i+1);
    HigherLimit=relativeVolatilities(i);
    theta(i)=BisectionFunction(Molefractions,relativeVolatilities,LowerLimit,HigherLimit);

end
relativeVolatilities;
theta
Coefficientss=zeros(NumberofCompounds-1,NumberofCompounds);
Coefficientss = Coefficientcalculation(relativeVolatilities,theta,NumberofCompounds)
Distillates=zeros(1,5);
for i=1:LK-1
    Distillates(1,i)=Flowrate(i);

end
Distillates(1,LK)=Flowrate(LK)*LKT;
Distillates(1,HK)=Flowrate(HK)*(1-HKB);
Distillates
D=sum(Distillates)
if HK-LK==1
    needed=Coefficientss(LK,:).*Distillates
    A=sum(needed)
    Rmin=(A/D)-1
     

elseif HK-LK>1
    needed1=zeros((HK-LK),1);
    needed2=zeros((HK-LK),1);
    for teta=LK:HK-1
        for i=1:LK
            needed1(teta,1)=needed1(teta,1)+Coefficientss(teta,i)*Distillates(1,i)
        end
        
        for i=HK:5
            needed2(teta,1)=needed2(teta,1)+Coefficientss(teta,i)*Distillates(1,i)
        end
        
        const=needed2+needed1;


    end
    LHS=Coefficientss((LK:HK-1),(LK+1):(HK-1))
    LHS(:,HK+1)=-1;
    
    zeroColumns = all(LHS == 0);
    LHS(:, zeroColumns) = [];
    LHS
    b=(-1)*const

   Z=[LHS,b]
   n= size(Z,1);
   x = zeros(n,1)
   for i=1:n-1
    for j=i+1:n
        m = Z(j,i)/Z(i,i);
        Z(j,:) = Z(j,:) - m*Z(i,:);
    end
   end
   x(n) = Z(n,n+1)/Z(n,n);
   for i=n-1:-1:1
    summ = 0
    for j=i+1:n
        summ = summ + Z(i,j)*x(j,:)
        x(i,:) = (Z(i,n+1) - summ)/Z(i,i)
    end
   end
    x
   linsolve(LHS,b)
               

    
end