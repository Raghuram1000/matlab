function [relativeVolatilities,LK,HK] = getRelativeVolatility_Raghu(Kvalues)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
display("First we need to identify the Heavy key and Light Key componenets");
display("Enter 1 if you want Ethane as Heavy key component");
display("Enter 2 if you want Propane as Heavy key component");
display("Enter 3 if you want n-Butane as Heavy key component");
display("Enter 4 if you want n-Pentane as Heavy key component");
display("Enter 5 if you want n-Hextane as Heavy key component");
Temp2 =input("Please give Heavy key component:  ", 's');
if isnan(str2double(Temp2))
    error('Invalid input. Please enter a numeric value.');
end
Temp2=str2double(Temp2);
r=mod(Temp2,2);
if r==0 || r==1
    display("You have entered integer.No Problem");

else
    error("You cannot enter floating numbers");
end
if Temp2<0
    error("No compounds are with negative labels.")

elseif Temp2>5
    error("There are only 5 compounds. Cannot do anything now");
else
    display("Your Heavy key component is noted. Don't be happy. Still there are further tests");
    HK=Temp2;
end
display("Enter 1 if you want Ethane as light key component");
display("Enter 2 if you want Propane as light key component");
display("Enter 3 if you want n-Butane as light key component");
display("Enter 4 if you want n-Pentane as light key component");
display("Enter 5 if you want n-Hextane as light key component");
Temp1 =input("Please give light key component:  ", 's');
if isnan(str2double(Temp1))
    error('Invalid input. Please enter a numeric value.');
end
Temp1=str2double(Temp1);
r=mod(Temp1,2);
if r==0
    display("You have entered integer.No Problem");
elseif r==1
    display("You have entered integer.No Problem");
else
    error("You cannot enter floating numbers");
end
if Temp1<0
    error("No compounds are with negative labels.")

elseif Temp1>5
    error("There are only 5 compounds. Cannot do anything now");
else
    display("Your light key component is noted.");
    LK=Temp1;
end
display("Now we see whether our light key and heavy key components are correct or not");
%Kvalues(LK)
%Kvalues(HK)
if Kvalues(LK)>Kvalues(HK)
    display("Congratulations. You can proceed. Now we will find relative volatilities");
elseif Kvalues(LK)==Kvalues(HK)
    error("Both heavy key and light key components cannot be same");
else 
   error("Working these two as light key and heavy key is not possible.");

end

for i=1:5
    relativeVolatilities(i)=Kvalues(i)/Kvalues(HK);
end






end