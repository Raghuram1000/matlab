function thetai = BisectionFunction(Molefraction,relativeVolatilities,LowerLimit,HigherLimit)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
temp1=(LowerLimit+HigherLimit)/2;
sum=0;
check =true;
for i=1:5
    sum=sum+(Molefraction(i)*relativeVolatilities(i))/(relativeVolatilities(i)-temp1);
   
end
if sum==0
    thetai=temp1;
    check=false;
elseif sum<0
    LowerLimit=temp1;
else
    HigherLimit=temp1;
end
while check
store=temp1;
temp1=(LowerLimit+HigherLimit)/2;
sum=0;
for i=1:5
    sum=sum+(Molefraction(i)*relativeVolatilities(i))/(relativeVolatilities(i)-temp1);
   
end
errorr=abs((store-temp1));
if sum==0
    thetai=temp1;
    check=false;
elseif errorr<0.005
    thetai=temp1;
    check=false;
elseif sum<0
    LowerLimit=temp1;
else
    HigherLimit=temp1;
end
end
end